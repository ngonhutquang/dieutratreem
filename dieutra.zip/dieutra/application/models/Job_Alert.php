<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Job_Alert extends MY_Model
{
    //ten bang du lieu
    public $table = 'job_alert';
}



?>