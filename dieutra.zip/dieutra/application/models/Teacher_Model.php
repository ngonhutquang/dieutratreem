<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	class Teacher_Model  extends MY_Model {

		public $table ='teacher';	


	}


?>