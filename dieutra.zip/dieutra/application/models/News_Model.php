<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class News_Model extends MY_Model
{
    //ten bang du lieu
    public $table = 'news';
}



?>