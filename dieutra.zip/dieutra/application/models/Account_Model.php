<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Account_Model extends MY_Model
{
    //ten bang du lieu
    public $table = 'account';
}



?>