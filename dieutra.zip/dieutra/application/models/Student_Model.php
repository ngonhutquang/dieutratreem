<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	class Student_Model  extends MY_Model {

		public $table ='student';	


	}


?>