<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	class DissertationDetail_Model  extends MY_Model {

		public $table ='dissertation_detail';	


	}


?>