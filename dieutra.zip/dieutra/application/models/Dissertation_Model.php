<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	class Dissertation_Model  extends MY_Model {

		public $table ='dissertation';	


	}


?>