<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class Static_Pages_Model extends MY_Model { 	
	
			public $table ='static_page';	

	 }


?>
