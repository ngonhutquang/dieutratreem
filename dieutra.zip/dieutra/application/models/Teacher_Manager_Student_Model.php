<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Teacher_Manager_Student_Model extends MY_Model
{
    //ten bang du lieu
    public $table = 'teacher_manager_student';
}



?>