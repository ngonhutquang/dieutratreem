

<?php 
	if (isset ($content_value)) {
		echo $content_value[0]->content;
	}

?>

