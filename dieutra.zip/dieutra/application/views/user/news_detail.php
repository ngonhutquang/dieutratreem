<div class="row">
  <div class="col-md-8">
   

		<h2><?php echo $news_detail->title ?> </h2>

		<div>
			<?php echo	$news_detail->content ?>
		</div>
             








  </div>
  <div class="col-md-4">
    
  </div>
</div>





	